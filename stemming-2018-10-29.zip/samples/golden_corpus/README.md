# Golden Arabic Corpus
This is a corpus for test Arabic stemmers.

## Requirements
 * Python3.* 

## Build json format

```sh 
     $ make build
```

