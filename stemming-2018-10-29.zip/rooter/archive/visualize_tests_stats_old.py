#!/usr/bin/python
# -*- coding=utf-8 -*-
#-----------------------------------------------------------------------
# Name:        light stemmer
# Purpose:     build an advanced stemmer for Information retreival 
#  
#
# Author:      Taha Zerrouki (taha.zerrouki[at]gmail.com)
#
# Created:     2016-06-14
# Copyright:   (c) Taha Zerrouki 2016
# Licence:     GPL
#-----------------------------------------------------------------------
"""
        Visualize charts from test stats
"""

import sys
if __name__ == "__main__":

    sys.path.append('../support')
    sys.path.append('../')

import re
import argparse
import os
import pandas as pd
from sklearn.metrics import precision_score, recall_score,  accuracy_score, f1_score
import numpy as np
import matplotlib.pyplot as plt


def grabargs():
    parser = argparse.ArgumentParser(description='Convert Quran Corpus into CSV format.')
    # add file name to import and filename to export
    
    parser.add_argument("-f", dest="filename", required=True,
    help="input file to convert", metavar="FILE")
    
    parser.add_argument("-o", dest="outfile", required=True,
    help="Output file to convert", metavar="OUT_FILE")
    
    parser.add_argument("--all", type=bool, nargs='?',
                        const=True, 
                        help="Test all stemmers.")
    args = parser.parse_args()
    return args
def visualize_latex(dtf , columns, outfile):
    """ convert data into latex table """
    df2 = dtf[columns]
    df2.to_latex(outfile+".tex", bold_rows= True, encoding='utf8')
    print("Data is written in %s"%outfile+".tex")
    
def visualize_latex_string(dtf , columns=[], caption="", label=""):
    """ convert data into latex table """
    if columns:
        df2 = dtf[columns]
    else:
        df2 = dtf
    tex = """
    \\begin{table} 
    %s
    \\caption{%s}
    \\label{%s:table}
    \\end{table}""" %(df2.to_latex(bold_rows= True, encoding='utf8'),
    caption, label,
    )
    return tex+'\n'
    #~ print("Data is written in %s"%outfile+".tex")
    
    
def figure_latex_string(caption="", label=""):
    """ return a figure latex code """
    tex = """
\\begin{figure}
    \\centering
    \\includegraphics[width=0.7\\linewidth]{images/%s}
    \\caption{%s}
    \\label{fig:%s}
\\end{figure}
    """ %(label, caption, label,
    )
    return tex+'\n'
    #~ print("Data is written in %s"%outfile+".tex")
    

def main():
    print("""
This program will generate Latex table codes and somes figures from statistics files from
Input files: are mentioned in the code, you must changes it if you want more files
output file:
    output/images
    tex file: outfile
    output/global.stats.csv: all joined data
    """)
    args =grabargs()
    filename = args.filename
    outfile = args.outfile
    #~ data_directory = args.data_directory
    all_stemmers = args.all
    # column types
    columns=[ 'total',
        'Stem macro Accuracy',
        'Stem macro F1 score',
        'Stem macro Precision',
        'Stem macro Recall',
        'Stem micro Accuracy',
        'Stem micro F1 score',
        'Stem micro Precision',
        'Stem micro Recall',
        'count',
        'linguistics accuracy',
        'macro Accuracy',
        'macro F1 score',
        'macro Precision',
        'macro Recall',
        'micro Accuracy',
        'micro F1 score',
        'micro Precision',
        'micro Recall',
        ]
    columns_type={
        #~ '':float,
        'count':np.int64,
        'micro Precision':np.float32,
        'Stem micro Recall':float,
        'Stem micro Accuracy':float,
        'Stem macro Precision':float,
        'macro F1 score':float,
        'linguistics accuracy':float,
        'macro Precision':float,
        'Stem macro Recall':float,
        'Stem macro Accuracy':float,
        'Stem macro F1 score':float,
        'Stem micro Precision':float,
        'micro Accuracy':float,
        'Stem micro F1 score':float,
        'macro Recall':float,
        'total':np.int64,
        'macro Accuracy':float,
        'micro Recall':float,
        'micro F1 score':float,
        }

    # visualize root extraction evaluation    
    # give columns and order
    columns1=['stemmer',  'total',
        #~ 'Stem macro Accuracy',
        #~ 'Stem macro F1 score',
        #~ 'Stem macro Precision',
        #~ 'Stem macro Recall',
        #~ 'Stem micro Accuracy',
        #~ 'Stem micro F1 score',
        #~ 'Stem micro Precision',
        #~ 'Stem micro Recall',
        'count',
        'linguistics accuracy',
        #~ 'macro Accuracy',
        #~ 'macro F1 score',
        #~ 'macro Precision',
        #~ 'macro Recall',
        'micro Accuracy',
        'micro F1 score',
        'micro Precision',
        'micro Recall',
        ]

    
    # visualize root extraction evaluation    
    # Macro evaluation
    # give columns and order
    columns2=['stemmer',  'total',
        #~ 'Stem macro Accuracy',
        #~ 'Stem macro F1 score',
        #~ 'Stem macro Precision',
        #~ 'Stem macro Recall',
        #~ 'Stem micro Accuracy',
        #~ 'Stem micro F1 score',
        #~ 'Stem micro Precision',
        #~ 'Stem micro Recall',
        #~ 'count',
        #~ 'linguistics accuracy',
        'macro Accuracy',
        'macro F1 score',
        'macro Precision',
        'macro Recall',
        #~ 'micro Accuracy',
        #~ 'micro F1 score',
        #~ 'micro Precision',
        #~ 'micro Recall',
        ]

    
    # visualize stem extraction evaluation    
    # Macro evaluation
    # give columns and order
    columns3=[ 'stemmer', 'total',
        #~ 'Stem macro Accuracy',
        #~ 'Stem macro F1 score',
        #~ 'Stem macro Precision',
        #~ 'Stem macro Recall',
        'Stem micro Accuracy',
        'Stem micro F1 score',
        'Stem micro Precision',
        'Stem micro Recall',
        #~ 'count',
        #~ 'linguistics accuracy',
        #~ 'macro Accuracy',
        #~ 'macro F1 score',
        #~ 'macro Precision',
        #~ 'macro Recall',
        #~ 'micro Accuracy',
        #~ 'micro F1 score',
        #~ 'micro Precision',
        #~ 'micro Recall',
        ]
    columns4=[ 'stemmer', 'total',
        'Stem macro Accuracy',
        'Stem macro F1 score',
        'Stem macro Precision',
        'Stem macro Recall',
        #~ 'Stem micro Accuracy',
        #~ 'Stem micro F1 score',
        #~ 'Stem micro Precision',
        #~ 'Stem micro Recall',
        #~ 'count',
        #~ 'linguistics accuracy',
        #~ 'macro Accuracy',
        #~ 'macro F1 score',
        #~ 'macro Precision',
        #~ 'macro Recall',
        #~ 'micro Accuracy',
        #~ 'micro F1 score',
        #~ 'micro Precision',
        #~ 'micro Recall',
        ]
    names ={"qindex":{'filename':'output/quran_word_v0.5.2.csv.stats', 'desc':'Quran word index'},
    
        "gold":{'filename':'output/gold.csv.stats',  'desc':"Arabic Golden Corpus"},
        "nafis":{'filename':'output/nafis.unq.stats', 'desc':"NAFIS"},
        "qcorpus":{'filename': 'output/qc.unq.stats', 'desc':"Quranic Arabic Corpus"},
    }
    pd.options.display.float_format = '{:,.2f}'.format
    try:
        outputfile = open(outfile+".tex","w")
    except:
        print ("Can't open file %s"%outfile)
        sys.exit()
    frames = []
    for key in names:
        filename = names[key]["filename"]
        df = pd.read_csv(filename, delimiter='\t',
              encoding = "utf-8",
              #~ skiprows=1,
              #~ names = columns, 
              dtype = columns_type, 
              )
        # rename first columns
        u'Unnamed: 0'
        df = df.rename(columns={u'Unnamed: 0': 'stemmer', })
        #add a new columns
        df['dataset'] = key
        # add frame to list in order to merge all data
        frames.append(df)

        print df.head(2)
        mytables=[{'caption'   : "Linguistic Accuracy and Micro classification F1-score on %s dataset "%names[key]["desc"],
            'label' : "%s-micro"%key,
            'columns':columns1,
            },
            {
            'caption'   : "Macro classification on %s dataset "%names[key]["desc"],
            'label' : "%s-macro"%key,
            'columns':columns2,
            },
            {
            'caption'   : "Stem Extraction evaluation  Micro classification on %s dataset "%names[key]["desc"],
            'label' : "%s-stmmicro"%key,
            'columns':columns3,
            },
            {
            'caption'   : "Stem Extraction evaluation  Macro classification on %s dataset "%names[key]["desc"],
            'label' : "%s-stmmacro"%key,
            'columns':columns4,
            },
            ]
        for mytab in mytables:
            outputfile.write("%% test of %s\n"%key)    
            caption   = "Linguistic Accuracy and Micro classification F1-score on %s dataset "%names[key]["desc"]
            label = "%s-micro"%key
            tex = visualize_latex_string(df, mytab['columns'], mytab['caption'], mytab['label'])
            outputfile.write(tex)


    # merge all data to build a pivot table
    df_global = pd.concat(frames)
    #  CHarts to generate 
    mycharts=[
    {'field':'linguistics accuracy', 'caption':"Root Extraction evaluation,Linguistic accuracy "},
    {'field':'macro F1 score', 'caption':"Root Extraction evaluation, Macro classification "},
    {'field':'micro F1 score', 'caption':"Root Extraction evaluation, Micro classification "},
    {'field':'Stem macro F1 score', 'caption':"Stem Extraction evaluation, Macro classification "},
    {'field':'Stem micro F1 score', 'caption':"Stem Extraction evaluation, Micro classification "},
    ]
    for mych in mycharts:
        field = mych.get('field','')
        label = field.replace(' ','-') 
        caption =   mych.get('caption','') 
        # pivoting table
        df_pivot = df_global.pivot(index='stemmer', columns='dataset', values=field)

        
        # generate data to latex
        tex = visualize_latex_string(df_pivot, caption=caption, label=label)
        outputfile.write(tex)

        # the latex code in not ordered to get homogenous tables
        # order by best max, in order to get a readable chart
        df_pivot.sort_values(by='gold', ascending = True, inplace=True)        
        # generate the latex figure code
        tex = figure_latex_string(caption=caption, label=label)
        outputfile.write(tex)

        # generate the plot
        plt.figure()
        df_pivot.plot(rot=15)
        plt.savefig("output/images/%s.png"%label)  

    df_global.to_csv("output/global.stats.csv", sep='\t', encoding='utf8')
    #~ print df_global
if __name__ == '__main__':
    main()
