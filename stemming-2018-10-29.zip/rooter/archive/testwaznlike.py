#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  stopclass.py
#  
#  Copyright 2018 zerrouki <zerrouki@majd4>
#  
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#  
#  
import re

import pyarabic.araby as araby
import rootslib


def test2():

    words = [(u'أفتضاربانني',u'ضرب'),
    (u'بأبأ',u'بءبء'),
    (u'يريدون',u'ريد'),
    (u'يستطعن', u'طوع'),
    (u'يستطيعون', u'طوع'),
    (u'الصيام', u'صوم'),
    (u'يخاف', u'خوف'),
    (u'كتاب',u'كتب'),
    (u"بالميدان",u'ميد'),
    (u"بالأسيهم",u'سهم'),
    (u"آخرين",u'ءخر'),
    (u"بالآخرة",u'ءخر'),    
    (u"لارتاب",u'ريب'),    
    (u"وسائل",u'وسل'),    
    (u"وصائل",u'وصل'),    
    (u"أخاه",u'ءخو'),    
    (u"أخوه",u'ءخو'),    
    (u"أخاهم",u'ءخو'),    
    (u"أخانا",u'ءخو'),  
    (u"بإذن",u'ءذن'),  
  
    ]
    
    for word, _ in words:
        for wazn in rootslib.WAZNS:
            root = rootslib.waznlike2(word, wazn, extract_root = True)
            # note an error when there are a root and length aren't equal
            error = root and (len(araby.strip_tashkeel(wazn)) != len(araby.strip_tashkeel(word)))
            print (u"\t".join([word, wazn, unicode(root), str(error)])).encode('utf8')
    samples=[
    (u"كتب",u'فعل'),
    (u"كتب",u'فعلَ'),
    (u"كتبٌ",u'فعل'),
    (u"مكتب",u'فعل'),
    ]
    for word, wazn in samples:    
        root = araby.waznlike(word, wazn, extract_root = True)
        root = araby.waznlike(word, wazn, extract_root = True)
        # note an error when there are a root and length aren't equal
        error = root and (len(araby.strip_tashkeel(wazn)) != len(araby.strip_tashkeel(word)))
        print (u"\t".join([word, wazn, unicode(root), str(error)])).encode('utf8')
            
    return 0
if __name__ == '__main__':
    test2()


def main(args):
    return 0

if __name__ == '__main__':
    import sys
    sys.exit(main(sys.argv))
